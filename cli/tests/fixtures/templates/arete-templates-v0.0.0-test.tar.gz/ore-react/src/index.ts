export const ok = true;
