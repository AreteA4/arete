# Using an installed protocol

`a4 install protocol <ref> --ts` generates the client under
`generated/typescript/protocols/<alias>/` (`arete.protocols.<name>` in a
session) with the protocol's stacks and programs hoisted alongside it.
`--rust` generates a crate over `arete-a4-sdk` and `--python` a package over
`arete-sdk`; see [Rust](#rust) and [Python](#python) below. Installing a
public protocol records the shared deployment only; no credentials are
written.

Your own deployed protocol installs the same way: activation publishes an
owner-private package, so `a4 install protocol <slug> --ts` resolves it for
your account with no deployment flag (other accounts can't). Never edit the
generated files; `a4 install --check` in CI fails when a client is not the
published release `arete.lock` pins.

## Execution receipts

A signed execution receipt connects a completed transaction signature to its
protocol deployment/release, instance, step, message hash and assessed fees.
It is distinct from the build receipt and from a UI execution/history entry.
Keep the transaction signatures and execution/instance ids returned by the flow.
If a receipt is not yet available, inspect finality and intent status; retry the
read rather than sending the transaction again.

Read a receipt with the generated client's `getReceipt(signature)` and the
published key set with `getReceiptKeys()` (check the installed SDK for language
spellings), or use:

- `GET /api/protocol-receipts/<signature>`
- `GET /api/protocol-receipts/keys`

Private deployment receipts require the owner/integrator's authorized API key;
public receipts and the key set can be read anonymously. The current CLI has no
dedicated receipt command. Never expose a secret key in browser code or logs to
fetch a private receipt; use an authenticated backend when needed.

Fetching JSON does not verify its claims. In TypeScript, `verifyReceipt` checks
receipt signatures against a trusted receipt-key set; `verifyReceiptOnChain`
checks the message/memo claims against chain transaction evidence. Check the
installed SDK's exact input types and validation result, and establish trust in
the key set rather than accepting arbitrary keys attached to a receipt. Query
the transaction on the receipt's actual chain: a dev-environment signature must
be read from that fork's RPC. Verify deployment/release, instance, step and fees
against the requested operation as well.

An absent private receipt can mean insufficient access rather than a missing
transaction. Receipt issuance also depends on service configuration and the
execution path; a standalone local protocol runtime does not issue hosted
receipts. Preserve errors and report that distinction rather than inventing a
receipt or treating absence as permission to resubmit.

Applications display any prepared fee and verify completed fees through the
receipt. Users do not manage classifications or request approval for fees.
See [fees](authoring.md#fees).

## Keys and access

- **Browser:** a publishable key, bound to the app's origin. The client can
  read, subscribe, and prepare and submit `public` steps (typically
  participant steps such as contribute, claim, refund).
- **Backend:** a secret key. Needed for `secret` steps (by default the
  create step and role steps). Never ship a secret key to the browser.
- The generated client is typed by key class: on a publishable-key client a
  `secret` step does not exist, so calling it is a compile error.
- When the key comes from `ARETE_API_KEY` (or a token) rather than
  `auth.secretKey`, the TypeScript client can't tell its class and types
  itself as publishable, so `secret` steps are missing. On a backend pass
  `keyClass: "secret"`:

  ```ts
  const client = createProtocolClient(TIP_JAR, { keyClass: "secret" }); // key from ARETE_API_KEY
  ```

- Sessions are minted and refreshed by the SDK through the session endpoint;
  you do not handle tokens.

## Choose the environment

One switch picks the environment; the installed client is the same file
either way. Run the app with `a4 dev run -- <command>` (sets
`ARETE_ENVIRONMENT=dev` and the edge URL) while `a4 dev up` runs, and every
installed SDK uses the cloud dev environment with no credential in the app.
Unset, it is production. `client.environment` says which.

For production, deploy only when authorized, run `a4 dev promote --check`,
then `a4 install --locked` and `a4 install --check`. Read the generated README
for connection options. Backend credentials can come from `ARETE_API_KEY`;
`ARETE_API_URL` selects the API origin, not the chain RPC. Never edit
generated ids or put a secret key or token in browser code. See
[local-dev.md](local-dev.md#the-apps-client-one-switch).

## Reads and live state

```ts
const raise = arete.protocols.tokenRaise;
const page = await raise.instances.list({ state: "open" });
const instance = await raise.instances.get(id);         // canonical state, accounts, metadata
const steps = await raise.allowedSteps({ instance: id, wallet });
// [{ step: "contribute", allowed: false, reason: "deadline_passed", detail: { now, "params.deadline": ... } }]
const subscription = raise.events(id, { onEvent: (event) => { /* transitions and named events */ } });
// subscription.close() when done; the SDK resumes with Last-Event-ID after reconnects.
```

Render `allowedSteps` to drive the UI, and show `reason` with its `detail`
operands. To ask what one wallet can do across the deployment (create steps
and every instance it relates to), use `raise.actions({ wallet })`
(`useWalletActions` in React, `actions(...)` in Rust and Python); each step
carries its `scope` and typed `args` (amounts and keys are strings with a
`format` such as `u64` or `pubkey`). Canonical state comes from the API; the protocol stack adds live
fields and may lag.

## Prepare, sign, submit

```ts
const result = await raise.steps.contribute.prepare(
  { instance: id, wallet, amount: "1000000000" },
  { transactionFormat: "v0" },
);
if (!result.ok) {
  switch (result.rejection.rejected) { /* exhaustive over the step's guard codes */ }
  throw new Error(`Preparation rejected: ${result.rejection.rejected}`);
}
// Each entry is the full wire transaction (Arete's signatures filled in,
// the wallet's slots empty) as base64: hand it to the wallet unchanged.
const signed = await signWithWallet(result.transactions.map((tx) => tx.transactionBase64));
const state = await raise.submit(result.intent, signed); // { executionId, state, transactions }
```

- The client never signs. Prepare returns the exact transactions to sign,
  already co-signed by Arete (attestation memo, ephemeral keys); the wallet
  adds its signature (`signTransaction` on a `VersionedTransaction`) and the
  app passes the signed bytes to `submit`. Do not modify them; submit refuses
  any changed byte.
- Transactions are Solana Transaction V1 by default. Wallets don't sign V1
  yet, so pass `{ transactionFormat: "v0" }` whenever a wallet signs
  (including `a4 dev`); the intent may then contain several transactions to
  sign together.
- `submit` returns the intent's state. Poll `intents.get(executionId)` until
  it is `completed`, `chain_failed`, `expired` or `rejected`:

  ```ts
  let state = await raise.submit(result.intent, signed);
  while (!["completed", "chain_failed", "expired", "rejected"].includes(state.state)) {
    await new Promise((r) => setTimeout(r, 500));
    state = await raise.intents.get(result.intent.executionId);
  }
  // result.intent.instanceId is the instance a create step opened
  ```

- Intents expire (about 60 seconds or the blockhash lifetime). Prepare again
  with the same idempotency key to get a linked replacement.
- If submission ends `submitted_unknown`, never resend: poll the intent.

## Metadata

`raise.metadata.instance(id).update(patch)` for creator fields (secret key);
participant fields need a wallet proof: sign the message the SDK builds for
the patch with the participant's wallet.

## Webhooks

Register an endpoint and subscribe to named events with a secret key. The
signing secret is returned once. From the project:

```bash
a4 protocol webhook add --url https://app.example/arete/webhook   # every event the build declares; --events a,b narrows it
a4 protocol webhook list
a4 protocol webhook test <id>        # a signed test delivery now
a4 protocol webhook remove <id>
```

`--secret-only` prints just the secret, to pipe into the host's secret store.
Endpoints must be public https. Verify every delivery:

```ts
import { verifyWebhook } from "@usearete/sdk";
const event = verifyWebhook(secret, rawBody, headers); // throws on a bad signature or stale timestamp
```

Payloads carry ids and states only; read details with your own key. Dedupe by
event id. You receive events for instances your account created, plus shared
instances if you opted in.

## Squads multisig setup

Protocols with admin steps propose them to the team's Squads v4 multisig with
a proposer key that belongs to **your account** (the one that deploys; one
proposer for every protocol you deploy). The
proposer may only initiate; Arete never votes or executes. The multisig is
named in the deployment config (a resource), and production deployment
create and activation are refused with `protocol-squads-setup-required`
(message and `details.setupUrl`) until it is an `active`
attachment of your account. Attach a multisig once and every protocol you
deploy can use it.

Guide the user in this order:

1. **Declare the multisig as a resource** of the protocol, never read from
   the instance or built by a create step.
2. **Ask** whether they already have a Squads multisig, and how its members
   sign: a hardware wallet, a browser wallet, or a keypair file.
3. **Send them to the dashboard**, https://app.arete.run/dashboard/squads. It
   works with any standard browser wallet, including a Ledger through
   Phantom, Solflare or Backpack. It attaches an existing multisig (and adds
   the proposer there) or creates a new one with the proposer already a
   member. For an existing multisig the **Squads app** works too: open the
   multisig, Members → Add member → paste the proposer → permission
   **Initiate only** → approve and execute. `a4 squads attach <multisig>`
   (or the `squads_attach` MCP tool) attaches it by address and prints the
   proposer to paste.
4. **Put the active multisig's address in the deployment config**: the
   dashboard and `a4 squads status <multisig>` show the snippet
   (`deploymentConfigSnippet`). Then deploy.

Check the setup from a terminal; these commands print the dashboard link
first and build no transactions:

```bash
a4 squads status                      # setup, proposer, attachments
a4 squads attach <multisig>           # attach by address; prints the Squads-app steps
a4 squads status <multisig>           # active once the proposal is approved and executed
```

Arete builds no Squads transactions. Only when the user wants it in code (a
script, or members whose key is a hot-wallet keypair), install the Squads v4
program SDK and use its Arete setup helpers to create a multisig with the
proposer, or to add the proposer to an existing one:

```bash
a4 install program squads-v4
```

The member's own wallet signs and sends, like any other transaction; never
hold or sign with a member's key, and never send it through a protocol
client's `submit`. Then re-check `a4 squads status <multisig>` (or the
dashboard) until the multisig is `active`; `problem` is `not_member` or
`permissions_invalid` until then. Fund the proposer too: it pays the fee and
rent of each proposal, and `a4 protocol squads status` reports
`proposer_unfunded` while it has too little SOL (`a4 dev fund <proposer> 1`
on a dev environment). A refused deploy's error carries the
dashboard link in `details.setupUrl`. Per deployment,
`client.squads.proposer()` and `client.squads.status(multisig)` still report
the proposer and its membership.

Dev environments keep their own proposer and are never checked against the
account's attachments. There `a4 dev squads` builds every transaction
locally and dev wallets sign:

```bash
a4 protocol squads proposer --dev                                 # the proposer <P>
a4 dev squads create --members alice,bob --threshold 1 --proposer <P>
# or, for an existing dev multisig:
a4 dev squads add-proposer --multisig <M> --proposer <P> --wallet alice   # prints the index <n>
a4 dev squads approve --multisig <M> --index <n> --wallet alice
a4 dev squads execute --multisig <M> --index <n> --wallet alice
a4 protocol squads status --dev --multisig <M>                    # ready
```

If the proposer is removed after activation, admin proposals are parked and
retried with backoff for up to 24 hours, and the instance stream emits a
system event:

```ts
raise.events(id, {
  onEvent: (event) => {
    if (event.type === "arete.squads.proposerMissing") {
      // event.data: { step, multisig, proposer, problem, instanceId, ... }
      promptTeamToAddProposer(event.data);
    }
  },
});
```

## Protocol stack rows

Each deployment has a generated stack with three entities: **Instances**
(`ProtocolInstance`), **Activity** (`ProtocolActivity`) and **Participants**
(`ProtocolParticipant`, only when the spec has a participant machine), plus
per-instance views (`byId`, `byInstance`). Stream them with the stack SDK, or
locally with `a4 stream --dev`. Fields to rely on:

| Field | Meaning |
|---|---|
| `instance` | the instance's short id (base58 of the UUID's bytes); rows are keyed by it |
| `instance_id` | the instance UUID the API and `a4 dev step` use. `a4 stream` adds it next to `instance` (`id.instance_id` on instance rows) in every output but `--raw`; other consumers convert the short id themselves |
| Activity rows | one per transaction Arete prepared: `step`, `wallet`, `amount`, `attested`, `via`, `slot`, `timestamp`, and `activity_account`, the account the step's `stack.activity` entry names as `instanceAccount` |
| `<step>_protocol_count`, `<step>_protocol_amount` | under an Instances row's `activity`: the step's attested transactions and amounts, each counted under the step its attested memo names |
| `<step>_count`, `<step>_amount`, `<step>_direct_count` | under an Instances row's `activity`: every matching instruction (attested or not), and how many bypassed Arete and called the programs directly |
| `<step>_count`, `<step>_amount` | under a Participants row's `activity`: that participant's attested per-step counts and amounts |

- Direct (bypass) activity is matched only on accounts the instance owns:
  those the create step binds from its ephemeral keys. A step whose
  `instanceAccount` is a wallet, a role or a shared account is counted from
  attested activity only, so its direct count stays zero.
- Instances rows don't carry the machine state; read it with
  `instances.get(id)` (or watch it in `a4 stream --dev --tui`).
- Canonical state comes from the API; the stack adds live fields and may
  lag.

## Rust

```bash
a4 install protocol <protocol-ref> --rust
```

The crate defines `<Name>PublishableClient` (only `public` steps) and
`<Name>SecretClient` (every client-callable step; refuses a publishable key),
with a `prepare_<step>` method per step. Both dereference to
`arete_sdk::protocol::ProtocolClient` for `instance`, `list_instances`,
`allowed_steps`, `submit`, `intent`, metadata, `events` and `squads()`.

```rust
use futures::StreamExt;
use arete_sdk::protocol::{ProtocolEventsOptions, ProtocolPrepareOptions, ProtocolStreamEvent, ProtocolTransactionFormat};
use token_raise_protocol::*;

let client = TokenRaiseSecretClient::from_env()?; // ARETE_API_KEY, backend only
let args = TokenRaiseContributeArgs { amount: 1_000_000_000u64.into() }; // ProtocolInteger
let options = ProtocolPrepareOptions::default()
    .with_transaction_format(ProtocolTransactionFormat::V0);
match client.prepare_contribute(&instance_id, &wallet, &args, options).await? {
    ProtocolPrepareResult::Prepared(prepared) => {
        // Sign each `transaction_base64` unchanged with the wallet.
        let signed = sign_with_wallet(&prepared.transactions)?;
        let state = client.submit(&prepared.intent.execution_id, signed).await?;
        // On SubmittedUnknown: read client.intent(..) until it settles; never resend.
    }
    // `rejection.code` is typed by the step's guard-code enum; `detail` holds the operands.
    ProtocolPrepareResult::Rejected(rejection) => show_rejection(rejection.rejected(), rejection.detail),
}

let mut events = client.events(&instance_id, ProtocolEventsOptions::default());
while let Some(event) = events.next().await {
    match event? {
        ProtocolStreamEvent::Emit { data, .. } => { /* named event */ }
        ProtocolStreamEvent::SquadsProposerMissing { data, .. } => { /* onboard the proposer */ }
        _ => {}
    }
}

let payload = verify_token_raise_webhook(&secret, &raw_body, &headers, Default::default())?.payload;
```

Squads (per deployment): `client.squads().proposer()` and
`client.squads().status(&multisig)`. Account setup is on the dashboard or
with `a4 squads` (as above).

## Python

```bash
a4 install protocol <protocol-ref> --python
```

The package defines `<Name>Client` (publishable key, `public` steps only) and
`<Name>SecretClient` (secret key, every client-callable step), with
`client.steps.<step>(...)` per step.

```python
from arete import AuthConfig
from arete.protocol import SQUADS_PROPOSER_MISSING_EVENT
from token_raise_protocol import TokenRaiseSecretClient, verify_token_raise_webhook

async with TokenRaiseSecretClient(auth=AuthConfig(secret_key=key)) as client:
    result = await client.steps.contribute(
        instance=instance_id, wallet=wallet, args={"amount": "1000000000"},
        transaction_format="v0",
    )
    if not result.ok:
        handle_rejection(result.rejected, result.detail)   # guard code + operands
    else:
        signed = sign_with_wallet([tx["transactionBase64"] for tx in result.transactions])
        state = await client.submit(result, signed)        # never resend after submitted_unknown

    async with client.events(instance_id) as stream:
        async for event in stream:
            if event.type == "emit":
                ...                                         # event.event is the spec's event name
            elif event.type == SQUADS_PROPOSER_MISSING_EVENT:
                ...                                         # onboard the proposer

    status = await client.squads.status(multisig)    # per deployment: proposer membership
    # Not ready: send the user to https://app.arete.run/dashboard/squads.

payload = verify_token_raise_webhook(secret, raw_body, headers).payload
```

Names above are from a `token-raise` install; read the generated README in
the installed folder for the exact class, method and guard-code names.
